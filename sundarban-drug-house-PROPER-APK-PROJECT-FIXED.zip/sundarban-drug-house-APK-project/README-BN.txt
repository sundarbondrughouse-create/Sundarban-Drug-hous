সুন্দরবন ড্রাগ হাউস — Proper Android APK Project

এই প্রজেক্টটি FINAL-8FIXED.zip-এর বর্তমান index.html/data structure রেখে Android WebView wrapper হিসেবে তৈরি।

যে Android-specific সমস্যাগুলো ঠিক করা হয়েছে:
- Camera permission + camera capture
- Phone Gallery / JSON Restore file picker
- Backup JSON সরাসরি Downloads/Sundarban Drug House Backups-এ save
- Phone/WhatsApp external intent
- Native Android Print/PDF dialog (Print -> Save as PDF)
- Android Back button support
- হিসাব Edit-এর robust update handling
- বর্তমান logo-কে launcher icon হিসেবে ব্যবহার

Build (GitHub Actions):
1. পুরো sundarban-drug-house-APK-project folder-এর contents একটি GitHub repository-এর root-এ upload করুন।
2. Actions -> Build Sundarban Drug House APK -> Run workflow.
3. Build শেষ হলে Artifacts থেকে sundarban-drug-house-debug-apk.zip নামিয়ে APK বের করুন।

নোট: এই প্রজেক্ট Android Studio/Gradle build-এর জন্য। ZIP-to-APK converter দিয়ে এই project ZIP দেবেন না।
