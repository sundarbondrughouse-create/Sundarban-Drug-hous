package com.sundarbandrughouse.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 9001;
    private static final int CAMERA_CAPTURE = 9002;
    private static final int CAMERA_PERMISSION = 9003;

    private WebView webView;
    private WebView printWebView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private boolean pendingCameraCapture = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);

        CookieManager.getInstance().setAcceptCookie(true);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternal(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternal(url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;

                boolean image = false;
                String[] types = params.getAcceptTypes();
                if (types != null) {
                    for (String t : types) {
                        if (t != null && t.toLowerCase().startsWith("image/")) {
                            image = true;
                            break;
                        }
                    }
                }

                if (params.isCaptureEnabled() && image) {
                    pendingCameraCapture = true;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
                        return true;
                    }
                    if (openCamera()) return true;
                }

                return openDocumentPicker(image);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean openDocumentPicker(boolean image) {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            pick.setType(image ? "image/*" : "application/json");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, image);
            }
            startActivityForResult(pick, FILE_CHOOSER);
            return true;
        } catch (ActivityNotFoundException e) {
            try {
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(image ? "image/*" : "application/json");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, image);
                startActivityForResult(pick, FILE_CHOOSER);
                return true;
            } catch (Exception ignored) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = null;
                return false;
            }
        }
    }

    private boolean handleExternal(String url) {
        if (url == null) return false;
        if (url.startsWith("tel:")) {
            try {
                Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
                startActivity(dial);
            } catch (Exception e) {
                Toast.makeText(this, "ফোন অ্যাপ খোলা যাচ্ছে না", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        if (url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/") || url.startsWith("whatsapp:")) {
            try {
                Intent wa = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(wa);
            } catch (Exception e) {
                Toast.makeText(this, "WhatsApp খোলা যাচ্ছে না", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        if (url.startsWith("file:") || url.startsWith("about:")) return false;
        if (url.startsWith("http://") || url.startsWith("https://")) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) {}
            return true;
        }
        return false;
    }

    private boolean openCamera() {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "SDH_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Sundarban Drug House");
            }
            cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (cameraUri == null) return false;

            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(cam, CAMERA_CAPTURE);
            return true;
        } catch (Exception e) {
            cameraUri = null;
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && pendingCameraCapture) {
                pendingCameraCapture = false;
                if (!openCamera()) openDocumentPicker(true);
            } else {
                pendingCameraCapture = false;
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = null;
                Toast.makeText(this, "ক্যামেরা permission না দিলে ক্যামেরা ব্যবহার করা যাবে না", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER || requestCode == CAMERA_CAPTURE) {
            if (fileCallback == null) return;
            Uri[] results = null;

            if (resultCode == RESULT_OK) {
                if (requestCode == CAMERA_CAPTURE && cameraUri != null) {
                    results = new Uri[]{cameraUri};
                } else if (requestCode == FILE_CHOOSER && data != null) {
                    if (data.getClipData() != null) {
                        int n = data.getClipData().getItemCount();
                        results = new Uri[n];
                        for (int i = 0; i < n; i++) {
                            Uri u = data.getClipData().getItemAt(i).getUri();
                            results[i] = u;
                            grantReadPermission(u, data);
                        }
                    } else if (data.getData() != null) {
                        Uri u = data.getData();
                        results = new Uri[]{u};
                        grantReadPermission(u, data);
                    }
                }
            } else if (requestCode == CAMERA_CAPTURE && cameraUri != null) {
                try { getContentResolver().delete(cameraUri, null, null); } catch (Exception ignored) {}
            }

            fileCallback.onReceiveValue(results);
            fileCallback = null;
            cameraUri = null;
            pendingCameraCapture = false;
        }
    }

    private void grantReadPermission(Uri uri, Intent data) {
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags == 0 ? Intent.FLAG_GRANT_READ_URI_PERMISSION : flags);
        } catch (Exception ignored) {}
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void saveBackup(String json, String filename) {
            runOnUiThread(() -> saveBackupFile(json, filename));
        }

        @JavascriptInterface
        public void printHtml(String bodyHtml) {
            runOnUiThread(() -> printHtmlNative(bodyHtml));
        }
    }

    private void saveBackupFile(String json, String filename) {
        try {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Sundarban Drug House Backups");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
            }
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Could not create file");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new Exception("Could not open file");
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
            }
            webView.evaluateJavascript("if(window.toast)toast('Backup সফলভাবে Downloads-এ সংরক্ষণ হয়েছে');", null);
        } catch (Exception e) {
            webView.evaluateJavascript("if(window.toast)toast('Backup সংরক্ষণ করা যায়নি');", null);
        }
    }

    private void printHtmlNative(String bodyHtml) {
        if (printWebView != null) {
            try { printWebView.destroy(); } catch (Exception ignored) {}
            printWebView = null;
        }

        printWebView = new WebView(this);
        WebSettings ps = printWebView.getSettings();
        ps.setJavaScriptEnabled(true);
        ps.setDefaultTextEncodingName("UTF-8");

        printWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                if (pm != null) {
                    PrintAttributes attrs = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    pm.print("সুন্দরবন ড্রাগ হাউস রিপোর্ট", printWebView.createPrintDocumentAdapter("report"), attrs);
                    Toast.makeText(MainActivity.this, "PDF/Print অপশন খুলেছে—Save as PDF নির্বাচন করুন", Toast.LENGTH_LONG).show();
                }
            }
        });

        String html = "<!doctype html><html lang='bn'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>PDF Report</title><style>body{font-family:sans-serif;padding:24px;color:#111}table{width:100%;border-collapse:collapse}th,td{border:1px solid #999;padding:7px;text-align:left}h1,h2{margin-top:0}@media print{body{padding:0}}</style></head><body>" + bodyHtml + "</body></html>";
        printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            // The HTML app manages its own history/modals. Let its history consume Back first.
            if (webView.canGoBack()) {
                webView.goBack();
                return;
            }
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        if (printWebView != null) printWebView.destroy();
        super.onDestroy();
    }
}
